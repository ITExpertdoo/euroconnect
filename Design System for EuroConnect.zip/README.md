
  # Design System for EuroConnect

  This is a code bundle for Design System for EuroConnect. The original project is available at https://www.figma.com/design/DK4fd6AlSnzaw9gNqo63bq/Design-System-for-EuroConnect.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  